package ali

import (
	"github.com/QuantumNous/new-api/relaykit/dto"
	"github.com/samber/lo"
)

// https://help.aliyun.com/document_detail/613695.html?spm=a2c4g.2399480.0.0.1adb778fAdzP9w#341800c0f8w0r

const EnableSearchModelSuffix = "-internet"

func requestOpenAI2Ali(request dto.GeneralOpenAIRequest, upstreamModelName string) *dto.GeneralOpenAIRequest {
	modelName := upstreamModelName
	if modelName == "" {
		modelName = request.Model
	}
	if !dto.IsQwenThinkingBudgetModel(modelName) {
		request.ThinkingBudget = nil
	}

	topP := lo.FromPtrOr(request.TopP, 0)
	if topP >= 1 {
		request.TopP = lo.ToPtr(0.999)
	} else if topP <= 0 {
		request.TopP = lo.ToPtr(0.001)
	}
	return &request
}
